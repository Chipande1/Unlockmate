
import React from 'react';
import { Shield, FileText } from 'lucide-react';

export const TermsOfService: React.FC = () => {
  return (
    <div className="max-w-4xl mx-auto py-12 px-4 animate-fade-in-up">
      <div className="text-center mb-12">
        <div className="inline-flex items-center justify-center p-3 bg-slate-100 rounded-full mb-4">
          <FileText className="h-6 w-6 text-slate-600" />
        </div>
        <h1 className="text-3xl font-bold text-slate-900">Terms of Service</h1>
        <p className="mt-2 text-slate-600">Last updated: {new Date().toLocaleDateString()}</p>
      </div>

      <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-8 space-y-8 text-slate-700 leading-relaxed">
        <section>
          <h2 className="text-xl font-bold text-slate-900 mb-3">1. Acceptance of Terms</h2>
          <p>
            By accessing and using UnlockMate ("the Service"), you accept and agree to be bound by the terms and provision of this agreement. In addition, when using this Service, you shall be subject to any posted guidelines or rules applicable to such services.
          </p>
        </section>

        <section>
          <h2 className="text-xl font-bold text-slate-900 mb-3">2. Description of Service</h2>
          <p>
            UnlockMate provides a document retrieval service that allows users to access study materials from various educational platforms. We act as an intermediary to facilitate access to educational content for research and study purposes.
          </p>
        </section>

        <section>
          <h2 className="text-xl font-bold text-slate-900 mb-3">3. User Conduct</h2>
          <p>
            You agree to use the Service only for lawful purposes. You represent that you are using unlocked documents for personal study, research, or educational purposes only. You agree not to distribute, sell, or commercially exploit any content retrieved through our Service.
          </p>
        </section>

        <section>
          <h2 className="text-xl font-bold text-slate-900 mb-3">4. Payment and Delivery</h2>
          <p>
            Payments are processed securely via Paystack. We operate on a "Pay Only When Ready" model. You are only required to pay once we have successfully located and prepared your document. Immediate access to the download link is granted upon successful payment confirmation.
          </p>
        </section>

        <section>
          <h2 className="text-xl font-bold text-slate-900 mb-3">5. Disclaimer of Warranties</h2>
          <p>
            The Service is provided "as is". UnlockMate makes no warranties, expressed or implied, regarding the accuracy, reliability, or completeness of the documents retrieved. We are not affiliated with CourseHero, Studocu, Scribd, or any other educational platform.
          </p>
        </section>

        <section>
          <h2 className="text-xl font-bold text-slate-900 mb-3">6. Limitation of Liability</h2>
          <p>
            UnlockMate shall not be liable for any direct, indirect, incidental, special, or consequential damages resulting from the use or the inability to use the service or for cost of procurement of substitute goods and services.
          </p>
        </section>
      </div>
    </div>
  );
};
