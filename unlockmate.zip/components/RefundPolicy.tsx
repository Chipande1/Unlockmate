
import React from 'react';
import { RefreshCcw, DollarSign } from 'lucide-react';

export const RefundPolicy: React.FC = () => {
  return (
    <div className="max-w-4xl mx-auto py-12 px-4 animate-fade-in-up">
      <div className="text-center mb-12">
        <div className="inline-flex items-center justify-center p-3 bg-slate-100 rounded-full mb-4">
          <RefreshCcw className="h-6 w-6 text-slate-600" />
        </div>
        <h1 className="text-3xl font-bold text-slate-900">Refund Policy</h1>
        <p className="mt-2 text-slate-600">Our commitment to customer satisfaction.</p>
      </div>

      <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-8 space-y-8 text-slate-700 leading-relaxed">
        <section>
          <h2 className="text-xl font-bold text-slate-900 mb-3">1. Satisfaction Guarantee</h2>
          <p>
            At UnlockMate, we strive to ensure you receive exactly the document you need. Our "Pay Only When Ready" system allows us to verify document availability before charging you. However, we understand that issues may occasionally arise.
          </p>
        </section>

        <section>
          <h2 className="text-xl font-bold text-slate-900 mb-3">2. Eligible Refund Scenarios</h2>
          <p>
            We will provide a full refund in the following cases:
          </p>
          <ul className="list-disc pl-5 mt-2 space-y-1">
            <li><strong>Corrupted File:</strong> The downloaded file is unreadable or blank.</li>
            <li><strong>Incorrect Document:</strong> The file unlocked does not match the URL provided.</li>
            <li><strong>Incomplete Unlock:</strong> The document content is significantly truncated or missing key pages compared to the preview.</li>
          </ul>
        </section>

        <section>
          <h2 className="text-xl font-bold text-slate-900 mb-3">3. Non-Refundable Scenarios</h2>
          <p>
            Refunds are generally not granted for:
          </p>
          <ul className="list-disc pl-5 mt-2 space-y-1">
            <li><strong>Change of Mind:</strong> You decided you no longer need the document after downloading it.</li>
            <li><strong>User Error:</strong> You provided the wrong URL for a document you did not intend to buy.</li>
            <li><strong>Platform Limitations:</strong> Minor formatting differences inherent to the conversion process that do not affect the readability of the content.</li>
          </ul>
        </section>

        <section>
          <h2 className="text-xl font-bold text-slate-900 mb-3">4. How to Request a Refund</h2>
          <p>
            To request a refund, please contact us via email at support@unlockmate.com within 24 hours of your purchase. Please include:
          </p>
          <ul className="list-disc pl-5 mt-2 space-y-1">
            <li>Your Order ID (found in "My Documents")</li>
            <li>The email address used for the purchase</li>
            <li>A brief description of the issue</li>
          </ul>
          <p className="mt-3">
            We aim to process all refund requests within 24-48 hours.
          </p>
        </section>
      </div>
    </div>
  );
};
