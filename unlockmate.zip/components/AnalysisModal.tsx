
import React from 'react';
import { Sparkles, Mail, Send, X, FileText, Lock, Loader2 } from 'lucide-react';
import { UnlockRequest } from '../types';

interface AnalysisModalProps {
  isOpen: boolean;
  request: UnlockRequest | null;
  email: string;
  onEmailChange: (email: string) => void;
  onSubmit: () => void;
  onCancel: () => void;
  isSubmitting?: boolean;
}

export const AnalysisModal: React.FC<AnalysisModalProps> = ({
  isOpen,
  request,
  email,
  onEmailChange,
  onSubmit,
  onCancel,
  isSubmitting = false
}) => {
  if (!isOpen || !request || !request.metadata) return null;

  return (
    <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[100] flex items-center justify-center p-4">
      <div className="bg-white w-full max-w-4xl rounded-2xl shadow-2xl overflow-hidden animate-fade-in-up relative max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="bg-slate-900 px-6 py-4 flex items-center justify-between sticky top-0 z-10 flex-shrink-0">
          <h2 className="text-white text-lg font-bold flex items-center gap-2">
            <Sparkles className="text-indigo-400 h-5 w-5" />
            Document Analysis Complete
          </h2>
          <button 
            onClick={!isSubmitting ? onCancel : undefined} 
            disabled={isSubmitting}
            className="text-slate-400 hover:text-white transition-colors p-1 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-6 sm:p-8">
          <div className="flex flex-col md:flex-row gap-8 h-full">
            
            {/* Left Column: Document Preview */}
            <div className="flex-1 bg-slate-100 rounded-xl p-6 flex flex-col items-center justify-center min-h-[400px]">
              <div className="bg-white shadow-lg border border-slate-200 w-full max-w-md aspect-[8.5/11] relative overflow-hidden transition-transform hover:scale-[1.01] duration-500">
                {/* Document Content Simulation */}
                <div className="p-8 h-full text-slate-800">
                  <div className="border-b border-slate-100 pb-4 mb-6">
                    <div className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-1">
                      {request.metadata.platform} • {request.metadata.subject}
                    </div>
                    <h3 className="text-2xl font-serif font-bold leading-tight">
                      {request.metadata.title}
                    </h3>
                  </div>
                  
                  <div className="font-serif text-sm leading-relaxed space-y-4 opacity-80 text-justify">
                    {request.metadata.preview_text ? (
                      request.metadata.preview_text.split('\n').map((paragraph, idx) => (
                        <p key={idx}>{paragraph}</p>
                      ))
                    ) : (
                       <>
                         <p>
                           Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
                         </p>
                         <p>
                           Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
                         </p>
                       </>
                    )}
                    <p>
                      Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam...
                    </p>
                  </div>
                </div>

                {/* Lock Overlay */}
                <div className="absolute inset-x-0 bottom-0 h-2/3 bg-gradient-to-t from-white via-white/90 to-transparent flex flex-col items-center justify-end pb-12">
                   <div className="bg-indigo-600 text-white px-6 py-3 rounded-full font-bold shadow-xl flex items-center gap-2 transform translate-y-2">
                     <Lock className="h-4 w-4" />
                     <span>Unlock Full Document</span>
                   </div>
                   <p className="text-slate-500 text-xs mt-3 font-medium">
                     {request.metadata.summary}
                   </p>
                </div>
              </div>
            </div>
            
            {/* Right Column: Action & Email */}
            <div className="flex flex-col gap-6 md:w-80 flex-shrink-0 pt-4">
              
              <div>
                <h3 className="text-xl font-bold text-slate-900 mb-2">Ready to Unlock?</h3>
                <p className="text-slate-600 text-sm">
                  We've successfully located this document. Enter your email below to receive the download link when it's ready.
                </p>
              </div>

              <div className="space-y-4">
                <div className="bg-indigo-50 border border-indigo-100 rounded-lg p-4">
                  <div className="flex items-start gap-3">
                    <FileText className="h-5 w-5 text-indigo-600 mt-0.5" />
                    <div>
                      <p className="font-bold text-slate-900 text-sm">File Verified</p>
                      <p className="text-xs text-indigo-700 mt-0.5">Content matches description</p>
                    </div>
                  </div>
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-2 block">
                    Your Email Address
                  </label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
                    <input
                      type="email"
                      required
                      placeholder="you@email.com"
                      className="w-full pl-9 pr-3 py-3 rounded-xl border border-slate-200 text-sm bg-white text-slate-900 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/10 outline-none transition-all shadow-sm"
                      value={email}
                      onChange={(e) => onEmailChange(e.target.value)}
                      autoFocus
                      disabled={isSubmitting}
                    />
                  </div>
                  <p className="text-xs text-slate-400 mt-2">
                    We'll notify you here. No spam, ever.
                  </p>
                </div>
              </div>

              <div className="mt-auto pt-4 space-y-3">
                <button 
                  onClick={onSubmit}
                  disabled={!email || isSubmitting}
                  className="w-full bg-indigo-600 text-white py-4 px-6 rounded-xl font-bold hover:bg-indigo-700 transition-colors shadow-lg shadow-indigo-600/20 flex items-center justify-center gap-2 whitespace-nowrap disabled:opacity-70 disabled:cursor-not-allowed text-lg"
                >
                  {isSubmitting ? (
                    <>
                      <Loader2 className="h-5 w-5 animate-spin" />
                      Processing...
                    </>
                  ) : (
                    <>
                      <Send className="h-5 w-5" />
                      Proceed to Unlock
                    </>
                  )}
                </button>
                <button 
                  onClick={onCancel}
                  disabled={isSubmitting}
                  className="w-full text-slate-500 hover:text-slate-700 font-medium text-sm py-2 hover:bg-slate-50 rounded-lg transition-colors disabled:opacity-50"
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
