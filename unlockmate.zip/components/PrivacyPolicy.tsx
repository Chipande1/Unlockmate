
import React from 'react';
import { Lock, Eye } from 'lucide-react';

export const PrivacyPolicy: React.FC = () => {
  return (
    <div className="max-w-4xl mx-auto py-12 px-4 animate-fade-in-up">
      <div className="text-center mb-12">
        <div className="inline-flex items-center justify-center p-3 bg-slate-100 rounded-full mb-4">
          <Lock className="h-6 w-6 text-slate-600" />
        </div>
        <h1 className="text-3xl font-bold text-slate-900">Privacy Policy</h1>
        <p className="mt-2 text-slate-600">Your privacy is important to us.</p>
      </div>

      <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-8 space-y-8 text-slate-700 leading-relaxed">
        <section>
          <h2 className="text-xl font-bold text-slate-900 mb-3">1. Information We Collect</h2>
          <p>
            We collect minimal information necessary to provide our service:
          </p>
          <ul className="list-disc pl-5 mt-2 space-y-1">
            <li><strong>Email Address:</strong> Required to send you document notifications and receipts.</li>
            <li><strong>Document URLs:</strong> The links you submit for analysis and unlocking.</li>
            <li><strong>Payment Information:</strong> Processed securely by Paystack. We do not store your credit card details on our servers.</li>
          </ul>
        </section>

        <section>
          <h2 className="text-xl font-bold text-slate-900 mb-3">2. How We Use Your Information</h2>
          <p>
            We use your information solely for:
          </p>
          <ul className="list-disc pl-5 mt-2 space-y-1">
            <li>Processing your document unlock requests.</li>
            <li>Sending you transaction confirmations and download links.</li>
            <li>Improving our AI analysis and service reliability.</li>
            <li> communicating with you regarding your orders or support inquiries.</li>
          </ul>
        </section>

        <section>
          <h2 className="text-xl font-bold text-slate-900 mb-3">3. Data Security</h2>
          <p>
            We implement a variety of security measures to maintain the safety of your personal information. All payment transactions are encrypted and processed through a gateway provider (Paystack) and are not stored or processed on our servers.
          </p>
        </section>

        <section>
          <h2 className="text-xl font-bold text-slate-900 mb-3">4. Third-Party Disclosure</h2>
          <p>
            We do not sell, trade, or otherwise transfer to outside parties your Personally Identifiable Information. This does not include website hosting partners and other parties who assist us in operating our website, conducting our business, or serving our users, so long as those parties agree to keep this information confidential.
          </p>
        </section>

        <section>
          <h2 className="text-xl font-bold text-slate-900 mb-3">5. Cookies</h2>
          <p>
            We use local storage on your device to remember your request history and user preferences to provide a better experience. We do not use tracking cookies for advertising purposes.
          </p>
        </section>
      </div>
    </div>
  );
};
